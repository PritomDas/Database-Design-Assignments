/*This is a program for B+ Tree based File Indexing.
* The file that is to be indexed is given as a text file. This program should ideally
* make an index file for the text file which contains the key and value of each record.
* It computes the offset value of every record and makes the index 
* based by the key supplied by the user.
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <string.h>
#include <cstring>
using namespace std;

//size of memory of blocks
const int memoryblock = 1024;

int degree;
int length_of_key;
long root_offset_addr;
string file_indexname;
string file_payload;

struct Node //tree node structure
{
    public:
    long address;
    long offset_addr_offset_addr_next; // address of offset_addr_offset_addr_next block
    long offset_addr_previous; // address of offset_addr_previous block
    bool is_leaf;
    vector<string> keys; //strings stored as keys
    vector<long> children; //offsets to store pointers to children nodes
    vector<long> pointers; //offsets to store pointers to file

    Node(long addr)
    {
        address = addr;
        file_read();
    }

    Node(bool leaf, vector<string> keys_, vector<long> vals, vector<long> ptrs) // constructor for nodes with multiple values
    {
        is_leaf = leaf;
        offset_addr_offset_addr_next = -1;
        offset_addr_previous = -1;
        address = -1;

        keys = keys_;

        if (leaf)
            pointers = vals;
        else
            children = ptrs;
    }

    Node(bool leaf, string key, long val, long ptr) // constructor of single value node 
    {
        is_leaf = leaf;
        offset_addr_offset_addr_next = -1;
        offset_addr_previous = -1;
        address = -1;

        keys.push_back(key);

        if (leaf)
            pointers.push_back(val);
        else
            children.push_back(ptr);
    }

    void node_clear()
    {
        is_leaf = false;
        offset_addr_offset_addr_next = -1;
        offset_addr_previous = -1;
        pointers.clear();
        keys.clear();
        children.clear();
    }
    
    void file_read() // read from index file
    {
        if (address <= 0)
            return;

        char *buf = new char[memoryblock];
        long offset = 0;
        fstream infile;
        infile.open(file_indexname, ios::in | ios::binary);
        infile.seekg(address);
        infile.read(buf, memoryblock);
        infile.close();

        memcpy(&is_leaf, buf + offset, sizeof(bool));
        offset = offset+ sizeof(is_leaf);
        memcpy(&offset_addr_offset_addr_next, buf + offset, sizeof(long));
        offset = offset+ sizeof(long);
        memcpy(&offset_addr_previous, buf + offset, sizeof(long));
        offset = offset+ sizeof(long);
        long keys_size;
        memcpy(&keys_size, buf + offset, sizeof(keys_size));
        offset = offset+ sizeof(keys_size);


        keys.clear();
        for (int var = 0 ; var < keys_size ; var++) 
        {
            string key(buf + offset, length_of_key); 
            offset = offset+ length_of_key + 1;
            keys.push_back(key);
        }

        if (is_leaf == false) 
        {
            children.clear();
            for (int var = 0 ; var < keys_size + 1 ; var++) 
            {
                long child;
                memcpy(&child, buf + offset, sizeof(child));
                offset = offset+ sizeof(child);
                children.push_back(child);
            }
        } 
        else // leaf node - read pointers
        {
            pointers.clear();
            for (long var = 0 ; var < keys_size ; var++) 
            {
                long pointer;
                memcpy(&pointer, buf + offset, sizeof(pointer));
                offset = offset+ sizeof(pointer);
                pointers.push_back(pointer);
            }
        }
    }

    Node* get_children(int idx)
    {
        long address = children[idx];
        Node *n = new Node(address);
        return n;
    }
};


void update_metadata();

Node* split_index_node(Node* index, string &key_p) 
{
    // splitting internal node - has (2*degree + 1) keys and (2*degree + 2) pointers
    key_p = index->keys[degree];
    index->keys.erase(index->keys.begin() + degree);
    
    // keep first degree keys and degree+1 pointers
    // move degree keys and degree+1 pointers to new node
    vector<string> new_keys;
    vector<long> new_children;

    new_children.push_back(index->children[degree + 1]);
    index->children.erase(index->children.begin() + degree + 1);
    
    while (index->keys.size() > degree) 
    {
        new_keys.push_back(index->keys[degree]);
        index->keys.erase(index->keys.begin() + degree);
        new_children.push_back(index->children[degree + 1]);
        index->children.erase(index->children.begin() + degree + 1);
    }

    vector<long> v1;
    Node* new_node = new Node(false, new_keys, v1, new_children);

    return new_node;
}

Node* split_leaf_node(Node* leaf) 
{
    vector<string> new_keys;
    vector<long> new_pointers;
    for(int var = degree ; var <= 2*degree ; var++) 
    {
        new_keys.push_back(leaf->keys[var]);
        new_pointers.push_back(leaf->pointers[var]);
    }
    
    // keep first 'degree' entries in the original leaf node
    for(int var = degree ; var <= 2*degree ; var++) 
    {
        leaf->keys.pop_back();
        leaf->pointers.pop_back();
    }
    
    vector<long> v1;
    Node* new_node = new Node(true, new_keys, new_pointers, v1);
    
    return new_node;
}

long record_finder(Node* root, string key)
{
    if (root == NULL)
        return -1;

    root->file_read();
    if (root->is_leaf) // reached a leaf node
    {
        for(int key_idx = 0 ; key_idx < root->keys.size() ; key_idx++)
        {
            if (key.compare(root->keys[key_idx]) == 0)
            {
                long p = root->pointers[key_idx];
                root->node_clear();
                return p;
            }
        }
        return -1;
    }
    else
    {
        for(int key_idx = 0 ; key_idx < root->keys.size() ; key_idx++)
        {
            if (key.compare(root->keys[key_idx]) < 0)
            {
                Node* c = root->get_children(key_idx);
                root->node_clear();
                return record_finder(c, key);
            }
        }
        Node* c = root->get_children(root->children.size() - 1);
        root->node_clear();
        return record_finder(c, key);
    }
}

void offset_of_rec(long key_offset)
{
    char buf[1001] = "";
    fstream infile(file_payload);
    infile.seekg(key_offset, infile.beg);
    infile.read(buf, 1000);
    infile.close();
    string str(buf);
    cout << str.substr(0, str.find("\n")) << endl;
}
 
void tree_creation()
{
    char temporary_memory[memoryblock];
    long offset = 0;

    fstream infile;
    infile.open(file_indexname, ios::in | ios::binary);
    infile.read(temporary_memory, memoryblock);
    infile.close();

    string get_file_payload(temporary_memory, 257);
    int end_idx = get_file_payload.find("0000");
    file_payload = get_file_payload.substr(0, end_idx);
    offset = offset+ 257;

    memcpy(&length_of_key, temporary_memory + offset, sizeof(length_of_key));
    offset = offset+ sizeof(length_of_key);

    memcpy(&degree, temporary_memory + offset, sizeof(degree));
    offset = offset+ sizeof(degree);

    memcpy(&root_offset_addr, temporary_memory + offset, sizeof(root_offset_addr));
    offset = offset+ sizeof(root_offset_addr);
}

void make_index(string data_file, string file_index, int keylen, long new_root_offset_addr)
{
   
    long offset = 0;
    char temporary_memory[memoryblock];

    string filename = data_file.append(string((256 - data_file.length()), '0'));
    memcpy(temporary_memory + offset, filename.c_str(), strlen(filename.c_str()) + 1);
    offset = offset+ strlen(filename.c_str()) + 1;

    memcpy(temporary_memory + offset, &keylen, sizeof(keylen));
    offset = offset+ sizeof(keylen);

    
    // assume 50 bytes for metadata (on the safe side)
    int degree = (memoryblock - 50)/ ((keylen+8)*2);

    memcpy(temporary_memory + offset, &degree, sizeof(degree));
    offset = offset+ sizeof(degree);

    if (new_root_offset_addr == -1) 
    {
        new_root_offset_addr = 1024;
        root_offset_addr = 1024;
    }
    memcpy(temporary_memory + offset, &new_root_offset_addr, sizeof(new_root_offset_addr));
    offset = offset+ sizeof(new_root_offset_addr);
    file_indexname = file_index;
    tree_creation();
    string line;
    fstream infile(file_payload);
    offset = 0;
    bool first_time = true;
    int count = 0;
    Node* root;
    while (getline(infile, line)) 
    {
        string key = line.substr(0, length_of_key);
        if (first_time)
        {
            root = new Node(true, key, offset, -1);
            first_time = false;
        }
        else
        {
            root = new Node(root_offset_addr);
        }
        offset = infile.tellg();;
        count++;
    }
    cout << "Successfully inserted " << count << " records in index file b+ tree." << endl;
}


void find_index(string file_index, string target_key)
{
    file_indexname = file_index;
    tree_creation();

    Node* root = new Node(root_offset_addr);

    long key_offset = record_finder(root, target_key);
    if (key_offset == -1)
        cout << "not found.\n";
    else
        offset_of_rec(key_offset);
}

int main(int argc, char **argv)
{
    string user_input(argv[1]);

    if (user_input.compare("-create") == 0)
    {
        string file_payload(argv[2]);
        string file_index(argv[3]);
        int keylen = atoi(argv[4]);
        make_index(file_payload, file_index, keylen, -1);
    }
    else if (user_input.compare("-find") == 0)
    {
        string file_index(argv[2]);
        string target_key(argv[3]);
        find_index(file_index, target_key);
    }
    return 0;
}